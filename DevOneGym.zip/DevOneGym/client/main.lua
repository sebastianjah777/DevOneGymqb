-- © 2024 [Tu nombre o el nombre de tu empresa]. Todos los derechos reservados.
-- Este script es propiedad de [Dev One] y está protegido por derechos de autor.

local QBCore = exports['qb-core']:GetCoreObject()


local isChinUpActive = false
local maxReps = 20

Citizen.CreateThread(function()
    local GymProps = {
        'prop_beach_bars_01',
        'prop_beach_bars_02',
        'prop_muscle_bench_05',
        'prop_beach_rings_01'
    }
    for _, prop in ipairs(GymProps) do
        exports['qb-target']:AddTargetModel(prop, {
            options = {
                {
                    type = "client",
                    event = "gym:client:StartChinUpFromProp",
                    icon = "fas fa-dumbbell",
                    label = "Hacer Barras"
                }
            },
            distance = 1.0
        })
    end
end)


RegisterNetEvent('gym:client:StartChinUpFromProp', function()
    if not isChinUpActive then
        isChinUpActive = true
        ExecuteCommand("e chinup")
        QBCore.Functions.Notify("¡Ejercicio iniciado!", "success")
        SendNUIMessage({ action = "showHud" }) 
        TriggerEvent('gym:client:StartTimer') 

        Citizen.CreateThread(function()
            local reps = 0
            while isChinUpActive do
                Citizen.Wait(2950) 
                reps = reps + 1

                
                SendNUIMessage({
                    action = "updateReps",
                    reps = reps,
                    goal = maxReps
                })

                
                if reps >= maxReps then
                    TriggerEvent('gym:client:StopChinUp')
                end
            end
        end)
    else
        QBCore.Functions.Notify("Ya estás realizando un ejercicio.", "error")
    end
end)


RegisterNetEvent('gym:client:StopChinUp', function()
    if isChinUpActive then
        isChinUpActive = false
        QBCore.Functions.Notify("Ejercicio terminado.", "success")
        SendNUIMessage({ action = "hideHud" }) 
        TriggerEvent('gym:client:StopTimer') 
        ExecuteCommand("e c") 
    end
end)


RegisterNetEvent('gym:client:StartTimer', function()
    SendNUIMessage({ action = "startTimer" })
end)


RegisterNetEvent('gym:client:StopTimer', function()
    SendNUIMessage({ action = "stopTimer" })
end)

        SendNUIMessage({ action = "resetTimer" })


RegisterNetEvent('gym:client:StopChinUp', function()
    if isChinUpActive then
        isChinUpActive = false
        QBCore.Functions.Notify("Ejercicio terminado.", "success")
        SendNUIMessage({ action = "hideHud" })

        
        local ped = PlayerPedId() 
        ClearPedTasksImmediately(ped) 
    end
end)

RegisterNetEvent('gym:client:StopChinUp', function()
    if isChinUpActive then
        isChinUpActive = false

        
        QBCore.Functions.Notify("Dejaste de hacer ejercicio.", "error")

        
        SendNUIMessage({ action = "hideHud" })

       
        local ped = PlayerPedId()
        ClearPedTasksImmediately(ped) 
    end
end)


Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)

        
        if IsControlJustPressed(0, 73) then 
            if isChinUpActive then
                
                TriggerEvent('gym:client:StopChinUp')
            end
        end
    end
end)


local isBenchPressActive = false
local maxBenchPressReps = 15


exports['qb-target']:AddTargetModel('prop_muscle_bench_03', {
    options = {
        {
            type = "client",
            event = "gym:client:StartBenchPressFromProp",
            icon = "fas fa-dumbbell",
            label = "Hacer Press Militar"
        }
    },
    distance = 2.0
})


RegisterNetEvent('gym:client:StartBenchPressFromProp', function()
    if not isBenchPressActive then
        isBenchPressActive = true

       
        local ped = PlayerPedId()
        local pedCoords = GetEntityCoords(ped)
        local closestProp = GetClosestObjectOfType(pedCoords, 2.0, GetHashKey('prop_muscle_bench_03'), false, false, false)

        if closestProp ~= 0 then
            
            local propCoords = GetEntityCoords(closestProp)
            local propHeading = GetEntityHeading(closestProp)

            
            local attachOffset = vector3(0.0, -0.1, -0.2) 
            local attachRotation = vector3(0.0, 0.0, 180.0) 

            
            AttachEntityToEntity(ped, closestProp, 0, attachOffset.x, attachOffset.y, attachOffset.z, attachRotation.x, attachRotation.y, attachRotation.z, false, false, false, true, 2, true)

            
            Citizen.Wait(500)

            
            TaskStartScenarioInPlace(ped, "PROP_HUMAN_SEAT_MUSCLE_BENCH_PRESS", 0, true)

            
            QBCore.Functions.Notify("¡Bench Press iniciado!", "success")
            SendNUIMessage({ action = "showHud" }) 
            TriggerEvent('gym:client:StartTimer') 

            
            Citizen.CreateThread(function()
                local reps = 0
                while isBenchPressActive do
                    Citizen.Wait(3000) 
                    reps = reps + 1

                    
                    SendNUIMessage({
                        action = "updateReps",
                        reps = reps,
                        goal = maxBenchPressReps
                    })

                    
                    if reps >= maxBenchPressReps then
                        TriggerEvent('gym:client:StopBenchPress')
                    end
                end
            end)
        else
            QBCore.Functions.Notify("No hay un banco cerca para hacer Bench Press.", "error")
            isBenchPressActive = false
        end
    else
        QBCore.Functions.Notify("Ya estás realizando un ejercicio.", "error")
    end
end)


RegisterNetEvent('gym:client:StopBenchPress', function()
    if isBenchPressActive then
        isBenchPressActive = false
        QBCore.Functions.Notify("Bench Press terminado.", "success")
        SendNUIMessage({ action = "hideHud" })
        TriggerEvent('gym:client:StopTimer') 
        
        local ped = PlayerPedId()
        ClearPedTasksImmediately(ped)
    end
end)


Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)

        
        if IsControlJustPressed(0, 73) then 
            if isBenchPressActive then
              
                TriggerEvent('gym:client:StopBenchPress')
            end
        end
    end
end)

local QBCore = exports['qb-core']:GetCoreObject()


local isWeightsActive = false
local maxReps = 20


Citizen.CreateThread(function()
    local GymProps = {
        'prop_weight_rack_02' 
    }
    for _, prop in ipairs(GymProps) do
        exports['qb-target']:AddTargetModel(prop, {
            options = {
                {
                    type = "client",
                    event = "gym:client:StartWeightsFromProp",
                    icon = "fas fa-dumbbell",
                    label = "Levantar Pesas"
                }
            },
            distance = 1.0
        })
    end
end)


RegisterNetEvent('gym:client:StartWeightsFromProp', function()
    if not isWeightsActive then
        isWeightsActive = true

        ExecuteCommand("e weights") 
        QBCore.Functions.Notify("¡Ejercicio iniciado!", "success")
        SendNUIMessage({ action = "showHud" }) 
        TriggerEvent('gym:client:StartTimer') 

        
        Citizen.CreateThread(function()
            local reps = 0
            while isWeightsActive do
                Citizen.Wait(4500) 
                reps = reps + 1

                
                SendNUIMessage({
                    action = "updateReps",
                    reps = reps,
                    goal = maxReps
                })

                
                if reps >= maxReps then
                    TriggerEvent('gym:client:StopWeights')
                end
            end
        end)
    else
        QBCore.Functions.Notify("Ya estás realizando un ejercicio.", "error")
    end
end)


RegisterNetEvent('gym:client:StopWeights', function()
    if isWeightsActive then
        isWeightsActive = false
        QBCore.Functions.Notify("Ejercicio terminado.", "success")
        SendNUIMessage({ action = "hideHud" }) 
        TriggerEvent('gym:client:StopTimer') 
        ExecuteCommand("e c") 
    end
end)


RegisterNetEvent('gym:client:StartTimer', function()
    SendNUIMessage({ action = "startTimer" })
end)


RegisterNetEvent('gym:client:StopTimer', function()
    SendNUIMessage({ action = "stopTimer" })
end)


Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)

        
        if IsControlJustPressed(0, 73) then 
            if isWeightsActive then
                
                TriggerEvent('gym:client:StopWeights')
            end
        end
    end
end)

local QBCore = exports['qb-core']:GetCoreObject()


local isGym2Active = false
local maxGym2Reps = 15


Citizen.CreateThread(function()
    local GymProps = {
        'prop_muscle_bench_01'
    }
    for _, prop in ipairs(GymProps) do
        exports['qb-target']:AddTargetModel(prop, {
            options = {
                {
                    type = "client",
                    event = "gym:client:StartGym2ExerciseFromProp",
                    icon = "fas fa-dumbbell",
                    label = "Hacer Abdominales"
                }
            },
            distance = 3.0
        })
    end
end)


RegisterNetEvent('gym:client:StartGym2ExerciseFromProp', function()
    if not isGym2Active then
        isGym2Active = true
        ExecuteCommand("e gym2") 
        QBCore.Functions.Notify("¡Ejercicio iniciado!", "success")
        SendNUIMessage({ action = "showHud" }) 
        TriggerEvent('gym:client:StartTimer') 

        
        Citizen.CreateThread(function()
            local reps = 0
            while isGym2Active do
                Citizen.Wait(900) 
                reps = reps + 1

               
                SendNUIMessage({
                    action = "updateReps",
                    reps = reps,
                    goal = maxGym2Reps
                })

                
                if reps >= maxGym2Reps then
                    TriggerEvent('gym:client:StopGym2Exercise')
                end
            end
        end)
    else
        QBCore.Functions.Notify("Ya estás realizando un ejercicio.", "error")
    end
end)


RegisterNetEvent('gym:client:StopGym2Exercise', function()
    if isGym2Active then
        isGym2Active = false
        QBCore.Functions.Notify("Ejercicio terminado.", "success")
        SendNUIMessage({ action = "hideHud" }) 
        TriggerEvent('gym:client:StopTimer') 
        ExecuteCommand("e c") 
        ClearPedTasksImmediately(PlayerPedId()) 
    end
end)


RegisterNetEvent('gym:client:StartTimer', function()
    SendNUIMessage({ action = "startTimer" })
end)


RegisterNetEvent('gym:client:StopTimer', function()
    SendNUIMessage({ action = "stopTimer" })
end)


Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)

        
        if IsControlJustPressed(0, 73) then 
            if isGym2Active then
                
                TriggerEvent('gym:client:StopGym2Exercise')
            end
        end
    end
end)

local QBCore = exports['qb-core']:GetCoreObject()


local isPushUpActive = false
local maxReps = 20


Citizen.CreateThread(function()
    local prop = {'prop_beach_dip_bars_01','prop_beach_dip_bars_02'}
    exports['qb-target']:AddTargetModel(prop, {
        options = {
            {
                type = "client",
                event = "gym:client:StartPushUp",
                icon = "fas fa-dumbbell",
                label = "Hacer Lagartijas"
            }
        },
        distance = 1.0
    })
end)


RegisterNetEvent('gym:client:StartPushUp', function()
    if not isPushUpActive then
        isPushUpActive = true
        ExecuteCommand("e pushup") 
        QBCore.Functions.Notify("¡Ejercicio iniciado!", "success")
        SendNUIMessage({ action = "showHud" }) 
        TriggerEvent('gym:client:StartTimer') 

        
        Citizen.CreateThread(function()
            local reps = 0
            while isPushUpActive do
                Citizen.Wait(1000) 
                reps = reps + 1

                
                SendNUIMessage({
                    action = "updateReps",
                    reps = reps,
                    goal = maxReps
                })

                
                if reps >= maxReps then
                    TriggerEvent('gym:client:StopPushUp')
                end
            end
        end)
    else
        QBCore.Functions.Notify("Ya estás realizando un ejercicio.", "error")
    end
end)


RegisterNetEvent('gym:client:StopPushUp', function()
    if isPushUpActive then
        isPushUpActive = false
        QBCore.Functions.Notify("Ejercicio terminado.", "success")
        SendNUIMessage({ action = "hideHud" }) 
        TriggerEvent('gym:client:StopTimer') 
        ExecuteCommand("e c") 
    end
end)


RegisterNetEvent('gym:client:StartTimer', function()
    SendNUIMessage({ action = "startTimer" })
end)


RegisterNetEvent('gym:client:StopTimer', function()
    SendNUIMessage({ action = "stopTimer" })
end)


Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)

        
        if IsControlJustPressed(0, 73) then 
            if isPushUpActive then
                
                TriggerEvent('gym:client:StopPushUp')
            end
        end
    end
end)

local QBCore = exports['qb-core']:GetCoreObject()


local isSquatActive = false
local maxReps = 15 


Citizen.CreateThread(function()
    local prop = 'prop_weight_squat' 
    exports['qb-target']:AddTargetModel(prop, {
        options = {
            {
                type = "client",
                event = "gym:client:StartSquat",
                icon = "fas fa-dumbbell",
                label = "Hacer Sentadillas"
            }
        },
        distance = 1.0
    })
end)


RegisterNetEvent('gym:client:StartSquat', function()
    if not isSquatActive then
        isSquatActive = true
        ExecuteCommand("e gym") 
        QBCore.Functions.Notify("¡Ejercicio  iniciado!", "success")
        SendNUIMessage({ action = "showHud" }) 
        TriggerEvent('gym:client:StartTimer') 

        
        Citizen.CreateThread(function()
            local reps = 0
            while isSquatActive do
                Citizen.Wait(2000) 
                reps = reps + 1

                
                SendNUIMessage({
                    action = "updateReps",
                    reps = reps,
                    goal = maxReps
                })

                
                if reps >= maxReps then
                    TriggerEvent('gym:client:StopSquat')
                end
            end
        end)
    else
        QBCore.Functions.Notify("Ya estás realizando un ejercicio.", "error")
    end
end)


RegisterNetEvent('gym:client:StopSquat', function()
    if isSquatActive then
        isSquatActive = false
        QBCore.Functions.Notify("sentadillas terminadas.", "success")
        SendNUIMessage({ action = "hideHud" }) 
        TriggerEvent('gym:client:StopTimer') 
        ExecuteCommand("e c") 
    end
end)


RegisterNetEvent('gym:client:StartTimer', function()
    SendNUIMessage({ action = "startTimer" })
end)


RegisterNetEvent('gym:client:StopTimer', function()
    SendNUIMessage({ action = "stopTimer" })
end)


Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)

        
        if IsControlJustPressed(0, 73) then 
            if isSquatActive then
                
                TriggerEvent('gym:client:StopSquat')
            end
        end
    end
end)

local QBCore = exports['qb-core']:GetCoreObject()


local isBoxingActive = false
local maxBoxingReps = 5


exports['qb-target']:AddTargetModel('prop_beach_punchbag', {
    options = {
        {
            type = "client",
            event = "gym:client:StartBoxingFromProp",
            icon = "fas fa-boxing-glove",
            label = "Hacer Boxing"
        }
    },
    distance = 1.0
})


RegisterNetEvent('gym:client:StartBoxingFromProp', function()
    if not isBoxingActive then
        isBoxingActive = true
        QBCore.Functions.Notify("¡Ejercicio iniciado!", "success")
        SendNUIMessage({ action = "showHud" }) 
        TriggerEvent('gym:client:StartTimer') 

        
        Citizen.CreateThread(function()
            local reps = 0
            while isBoxingActive do
                ExecuteCommand("e boxing") 
                Citizen.Wait(2500) 
                reps = reps + 1

                
                SendNUIMessage({
                    action = "updateReps",
                    reps = reps,
                    goal = maxBoxingReps
                })

                
                if reps >= maxBoxingReps then
                    TriggerEvent('gym:client:StopBoxing')
                end
            end
        end)
    else
        QBCore.Functions.Notify("Ya estás realizando un ejercicio.", "error")
    end
end)


RegisterNetEvent('gym:client:StopBoxing', function()
    if isBoxingActive then
        isBoxingActive = false
        QBCore.Functions.Notify("Ejercicio terminado.", "success")
        SendNUIMessage({ action = "hideHud" }) 
        TriggerEvent('gym:client:StopTimer') 
        ExecuteCommand("e c") 
    end
end)


RegisterNetEvent('gym:client:StartTimer', function()
    SendNUIMessage({ action = "startTimer" })
end)


RegisterNetEvent('gym:client:StopTimer', function()
    SendNUIMessage({ action = "stopTimer" })
end)


Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if IsControlJustPressed(0, 73) then 
            if isBoxingActive then
                TriggerEvent('gym:client:StopBoxing')
            end
        end
    end
end)

local QBCore = exports['qb-core']:GetCoreObject()


local isTreadmillActive = false
local maxTreadmillReps = 1000 


exports['qb-target']:AddTargetModel('apa_p_apdlc_treadmill_s', {
    options = {
        {
            type = "client",
            event = "gym:client:StartTreadmill",
            icon = "fas fa-running",
            label = "Correr en la caminadora"
        }
    },
    distance = 2.0
})


local function LoadAnimDict(dict)
    while not HasAnimDictLoaded(dict) do
        RequestAnimDict(dict)
        Citizen.Wait(10)
    end
end


RegisterNetEvent('gym:client:StartTreadmill', function()
    if not isTreadmillActive then
        isTreadmillActive = true

        
        local ped = PlayerPedId()
        local pedCoords = GetEntityCoords(ped)
        local closestProp = GetClosestObjectOfType(pedCoords, 2.0, GetHashKey('apa_p_apdlc_treadmill_s'), false, false, false)

        if closestProp ~= 0 then
            
            local propCoords = GetEntityCoords(closestProp)
            local propHeading = GetEntityHeading(closestProp)

            
            SetEntityCoords(ped, propCoords.x, propCoords.y, propCoords.z + 0.5)
            SetEntityHeading(ped, (propHeading + 180) % 360)

            
            LoadAnimDict("move_action@p_m_two@unarmed@core")
            TaskPlayAnim(ped, "move_action@p_m_two@unarmed@core", "run", 8.0, -8.0, -1, 1, 0, false, false, false)

           
            QBCore.Functions.Notify("¡Ejercicio iniciado!", "success")
            SendNUIMessage({ action = "showHud" })

           
            Citizen.CreateThread(function()
                local currentReps = 0
                while isTreadmillActive do
                    Citizen.Wait(500) 
                    currentReps = currentReps + 1

                    
                    SendNUIMessage({
                        action = "updateReps",
                        reps = currentReps,
                        goal = maxTreadmillReps
                    })

                    
                    if currentReps >= maxTreadmillReps then
                        TriggerEvent('gym:client:StopTreadmill')
                    end
                end
            end)
        else
            QBCore.Functions.Notify("No hay una caminadora cerca.", "error")
            isTreadmillActive = false
        end
    else
        QBCore.Functions.Notify("Ya estás realizando un ejercicio.", "error")
    end
end)


RegisterNetEvent('gym:client:StopTreadmill', function()
    if isTreadmillActive then
        isTreadmillActive = false
        QBCore.Functions.Notify("Ejercicio terminado.", "success")
        SendNUIMessage({ action = "hideHud" }) 
        ClearPedTasksImmediately(PlayerPedId())
    end
end)


Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if IsControlJustPressed(0, 73) and isTreadmillActive then
            TriggerEvent('gym:client:StopTreadmill')
        end
    end
end)

