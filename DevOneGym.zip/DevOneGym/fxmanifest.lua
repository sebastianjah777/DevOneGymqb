fx_version 'cerulean'
game 'gta5'

author 'DevOneGym'
description 'Script de gimnasio realista'
version '1.0.0'

-- Scripts cliente y servidor
client_scripts {
    'client/main.lua',
    --'client/*.lua'
}

server_scripts {
    'server/main.lua'
}

-- Archivos de interfaz
ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js'
}

-- Dependencias
dependencies {
    'qb-core',
    'qb-target'
}
