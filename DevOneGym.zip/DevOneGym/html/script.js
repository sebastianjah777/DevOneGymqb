window.addEventListener('message', (event) => {
    const data = event.data;
    const hud = document.getElementById('futuristicHUD');

    switch (data.action) {
        case 'showHud':
            hud.classList.remove('hidden');
            hud.classList.add('visible');
            break;
        case 'hideHud':
            hud.classList.remove('visible');
            hud.classList.add('hidden');
            break;
        case 'updateHud':
            document.getElementById('reps').textContent = data.reps;
            document.getElementById('timer').textContent = data.timer;
            document.querySelector('.progress-fill').style.width = `${data.progress}%`;
            break;
    }
});

let timerRunning = false;
let timerSeconds = 0;
let intervalId = null;

// Escucha eventos del cliente
window.addEventListener('message', (event) => {
    const data = event.data;

    switch (data.action) {
        case "showHud":
            document.getElementById("futuristicHUD").classList.remove("hidden");
            break;

        case "hideHud":
            document.getElementById("futuristicHUD").classList.add("hidden");
            break;

        case "updateReps":
            document.getElementById("reps").textContent = data.reps;
            const progress = (data.reps / data.goal) * 100;
            document.querySelector(".progress-fill").style.width = `${Math.min(progress, 100)}%`;
            break;

        default:
            console.warn(`Acción no reconocida: ${data.action}`);
            break;
    }
});

window.addEventListener('message', (event) => {
    let data = event.data;

    if (data.action === 'startTimer') {
        // Inicia el temporizador
        if (!timerInterval) {
            timerInterval = setInterval(() => {
                timerSeconds++;
                updateTimerDisplay();
            }, 1000);
        }
    }

    if (data.action === 'stopTimer') {
        // Detener temporizador
        clearInterval(timerInterval);
        timerInterval = null;
    }

    if (data.action === 'resetTimer') {
        // Reinicia el temporizador
        clearInterval(timerInterval);
        timerInterval = null;
        timerSeconds = 0;
        updateTimerDisplay();
    }
});

function updateTimerDisplay() {
    const minutes = String(Math.floor(timerSeconds / 60)).padStart(2, '0');
    const seconds = String(timerSeconds % 60).padStart(2, '0');
    document.getElementById('timer').textContent = `${minutes}:${seconds}`;
}



    
